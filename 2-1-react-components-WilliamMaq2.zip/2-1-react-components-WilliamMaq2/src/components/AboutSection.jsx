import { Caracteristicas } from "./Caracteristicas";

export function AboutSection() {

    let nome = "William Marques"
  return (
    <>
      <h1>
        {nome}
      </h1>
      <p>Gosto de Jogar CS2, gosto de Hamburguer e Pizza</p>
      <Caracteristicas />
    </>
  );
}
