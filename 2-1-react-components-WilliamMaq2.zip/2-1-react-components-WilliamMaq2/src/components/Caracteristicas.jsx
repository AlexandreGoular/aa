export function Caracteristicas() {

  return (
    <>
      <ul>
        <li>Jogar</li>
        <li>Comer</li>
        <li>Dormir</li>
        <li>Estudar</li>
        <li>Papear</li>
      </ul>
    </>
  );
}
