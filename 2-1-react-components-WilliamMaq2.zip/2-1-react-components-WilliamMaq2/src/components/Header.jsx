import '../css/navbar.css'
export function Header() {

    let nome = "William"
  return (
    <>
      <h1>Ola eu sou {nome}</h1>
    </>
  );
}
