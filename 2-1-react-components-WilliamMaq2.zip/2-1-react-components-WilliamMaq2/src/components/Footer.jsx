export function Footer() {

    let nome = "William"
  return (
    <>
      <p>Todos os direitos reservados à {nome}</p>
    </>
  );
}
