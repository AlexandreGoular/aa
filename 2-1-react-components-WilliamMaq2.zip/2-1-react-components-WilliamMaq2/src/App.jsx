import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { AboutSection } from './components/AboutSection';
function App() {

  return (
    <>
      <Header />
      <AboutSection />
      <Footer />
    </>
  )
}

export default App
